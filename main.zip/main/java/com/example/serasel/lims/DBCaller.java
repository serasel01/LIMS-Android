package com.example.serasel.lims;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class DBCaller {
    private Context context;

    public DBCaller(Context context) {
        this.context = context;
    }

    public void updateToDatabase(final String barcode, final HashMap<String, Book> booklist) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=scanBook";

        final Book book = booklist.get(barcode);
        book.setNo_scanned(book.getNo_scanned() + 1);
        book.setScanned(true);

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject object = new JSONObject(response);
                                    String message = object.getString("message");

                                    if (message.equals("Disabled account")){
                                        Toast.makeText(context, "Your account has been disabled", Toast.LENGTH_LONG).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {}
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<>();
                        params.put("id", String.valueOf(book.getId()));
                        params.put("noscanned", String.valueOf(book.getNo_scanned()));
                        params.put("isScanned", "1");
                        params.put("barcode", barcode);
                        params.put("user_id", SharedPrefs.getInstance(context).getId());
                        return params;
                    }
                };

                AppSingleton.getInstance(context).addToRequestQueue(postRequest);
    }

    public void signin(final String id, final String password, final secondPage.CheckUserCallBack checkUserCallBack) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=signin";


        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            Toast.makeText(context, String.valueOf(obj.getBoolean("error")), Toast.LENGTH_LONG).show();
                            checkUserCallBack.onCheckCallBack(obj.getBoolean("error"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {}
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<>();
                params.put("id", id);
                params.put("password", password);
                return params;
            }
        };

        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }

    public void checkIP(final ImageView ip_check) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=checkIP";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(context, "SUCCESSFULLY CONNECTED TO DATABASE", Toast.LENGTH_LONG).show();
                        ip_check.setVisibility(View.VISIBLE);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, "INVALID IP ADDRESS", Toast.LENGTH_LONG).show();
                        ip_check.setVisibility(View.INVISIBLE);
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<>();
                return params;
            }
        };

        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }

    public void logout(final String id) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=logout";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {

                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {}
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };

        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }

    public void addBook(final String title, final String barcode, final String call_no,
                        final int id, final String section) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=addBook";

                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject object = new JSONObject(response);
                                    String message = object.getString("message");

                                    if (message.equals("Disabled account")){
                                        Toast.makeText(context, "Your account has been disabled", Toast.LENGTH_LONG).show();
                                    } else {
                                        Toast.makeText(context, title + "(" + barcode + ") was added succesfully",
                                                Toast.LENGTH_LONG).show();
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {}
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<>();
                        params.put("title", title);
                        params.put("call_no", call_no);
                        params.put("barcode", barcode);
                        params.put("id", String.valueOf(id));
                        params.put("section", section);
                        params.put("user_id", SharedPrefs.getInstance(context).getId());
                        return params;
                    }
                };

        Toast.makeText(context, title + " (" + barcode + ") has added successfully .", Toast.LENGTH_SHORT).show();
        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }

    public void getListOfBooks(final String section, final ScanningActivity.GetListCallBack list_call) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=get_booklist";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            String message = object.getString("message");

                            if (message.equals("Disabled account")){
                                Toast.makeText(context, "Your account has been disabled", Toast.LENGTH_LONG).show();

                            } else {
                                try {
                                    HashMap<String, Book> booboo = new HashMap<>();

                                    JSONObject obj = new JSONObject(response);
                                    JSONArray jsonArray = obj.getJSONArray("data");

                                    for (int i = 0; i < jsonArray.length(); i++){
                                        JSONObject jo = jsonArray.getJSONObject(i);
                                        Book book = new Book();

                                        String title = jo.getString("title");
                                        book.setTitle(title.replaceAll("/", "\n"));

                                        book.setBarcode(jo.getString("barcode"));
                                        book.setTotal_no(Integer.parseInt(jo.getString("total_no")));
                                        book.setId(Integer.parseInt(jo.getString("id")));
                                        book.setNo_scanned(Integer.parseInt(jo.getString("no_scanned")));

                                        if(jo.getString("is_scanned").equals("1")){
                                            book.setScanned(true);
                                        } else if (jo.getString("is_scanned").equals("0")){
                                            book.setScanned(false);
                                        }

                                        booboo.put(book.getBarcode(), book);
                                    }

                                    list_call.onListCallBack(booboo);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {}
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<>();
                params.put("section", section);
                params.put("user_id", SharedPrefs.getInstance(context).getId());
                return params;
            }
        };

        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }

    public void getListOfBooks(final String section, final InputBtn.GetListCallBack list_call) {
        String url = "http://" + SharedPrefs.getInstance(context).getIpaddress() + "/LIMS/index.php?op=get_booklist";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            String message = object.getString("message");

                            if (message.equals("Disabled account")){
                                Toast.makeText(context, "Your account has been disabled", Toast.LENGTH_LONG).show();

                            } else {
                                try {
                                    HashMap<String, Book> booboo = new HashMap<>();

                                    JSONObject obj = new JSONObject(response);
                                    JSONArray jsonArray = obj.getJSONArray("data");

                                    for (int i = 0; i < jsonArray.length(); i++){
                                        JSONObject jo = jsonArray.getJSONObject(i);
                                        Book book = new Book();

                                        String title = jo.getString("title");
                                        book.setTitle(title.replaceAll("/", "\n"));

                                        book.setBarcode(jo.getString("barcode"));
                                        book.setTotal_no(Integer.parseInt(jo.getString("total_no")));
                                        book.setId(Integer.parseInt(jo.getString("id")));
                                        book.setNo_scanned(Integer.parseInt(jo.getString("no_scanned")));

                                        if(jo.getString("is_scanned").equals("1")){
                                            book.setScanned(true);
                                        } else if (jo.getString("is_scanned").equals("0")){
                                            book.setScanned(false);
                                        }

                                        booboo.put(book.getBarcode(), book);
                                    }

                                    list_call.onListCallBack(booboo);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {}
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<>();
                params.put("section", section);
                params.put("user_id", SharedPrefs.getInstance(context).getId());
                return params;
            }
        };

        AppSingleton.getInstance(context).addToRequestQueue(postRequest);

    }
}
