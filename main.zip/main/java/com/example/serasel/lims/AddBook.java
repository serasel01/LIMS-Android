package com.example.serasel.lims;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import java.util.Random;

public class AddBook extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private Button newbook, back;
    private EditText titleB,enterB,call;
    private Spinner section_spinner;
    private String section;
    private Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        activity = this;

        newbook = (Button) findViewById(R.id.newbook);
        back = (Button) findViewById(R.id.back);
        titleB = (EditText) findViewById(R.id.titleB);
        enterB = (EditText) findViewById(R.id.enterB);
        call = (EditText) findViewById(R.id.call);

        section_spinner = findViewById(R.id.section_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter
                .createFromResource(this,R.array.Sections, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        section_spinner.setAdapter(adapter);
        section_spinner.setOnItemSelectedListener(this);

        newbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleB.getText().toString();
                String enter = enterB.getText().toString();
                String callN = call.getText().toString();
                int id = getRandomNumberInRange(1, 999999);

                DBCaller caller = new DBCaller(getApplicationContext());
                caller.addBook(title,enter,callN, id, section);

                SharedPrefs.getInstance(getApplicationContext())
                        .updateLog(title
                                + " (" + enter + ") was added.");

                Intent returnIntent = new Intent();
                setResult(activity.RESULT_CANCELED,returnIntent);
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });



//        bt = (Button)findViewById(R.id.teb);
//        bt.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                openAdd();
//            }
//        });
    }
    public void openAdd() {
        Intent intent = new Intent(this, AddBook.class);
        startActivity(intent);
    }

    private static int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        section= parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
