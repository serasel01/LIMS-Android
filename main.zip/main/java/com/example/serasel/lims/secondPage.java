package com.example.serasel.lims;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class secondPage extends AppCompatActivity {
private Button button;
private EditText id, password, et_ip_address;
private Activity activity;
private ImageView ip_check;

    public interface CheckUserCallBack {
        void onCheckCallBack(Boolean error);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        setContentView(R.layout.activity_second_page);
        button = (Button)findViewById(R.id.signIn);
        id = (EditText) findViewById(R.id.id);
        ip_check = findViewById(R.id.ip_check);
        password = (EditText) findViewById(R.id.password);
        et_ip_address = findViewById(R.id.et_ip_address);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(SharedPrefs.getInstance(getApplicationContext()).getIpaddress() == null){
                    Toast.makeText(getApplicationContext(), "Please verify the IP address first.",
                            Toast.LENGTH_LONG).show();
                } else {
                    openSecond();
                }
            }
        });

        ip_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ip = et_ip_address.getText().toString();
                new DBCaller(getApplicationContext()).checkIP(ip_check, ip, et_ip_address);
            }
        });

    }

    public void openSecond() {
        final String user_id = id.getText().toString();
        String user_password = password.getText().toString();
        DBCaller caller = new DBCaller(getApplicationContext());
        caller.signin(user_id, user_password, new CheckUserCallBack() {
            @Override
            public void onCheckCallBack(Boolean error) {
                if(error){
                    Toast.makeText(getApplicationContext(), "Invalid user or password",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Sign in Success",
                            Toast.LENGTH_LONG).show();
                    SharedPrefs.getInstance(getApplicationContext()).updateId(user_id);

                    Intent intent = new Intent(getApplicationContext(),ScanningActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }


}
