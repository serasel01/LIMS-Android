package com.example.serasel.lims;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

public class LogoutDialog extends Dialog {
    private Button btn_yes, btn_no;
    private Activity activity;

    public LogoutDialog(Activity activity) {
        super(activity);
        this.activity = activity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_logout);

        initViews();
    }

    private void initViews() {
        btn_yes = findViewById(R.id.btn_yes);
        btn_yes.setOnClickListener(new Yes());
        btn_no = findViewById(R.id.btn_no);
        btn_no.setOnClickListener(new No());

    }

    private class Yes implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            new DBCaller(getContext()).logout(SharedPrefs.getInstance(getContext()).getId());
            SharedPrefs.getInstance(getContext()).logout();

            Intent out = new Intent(getContext(), secondPage.class);
            out.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            getContext().startActivity(out);
            activity.finish();
            dismiss();
        }
    }

    private class No implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            dismiss();
        }
    }
}
