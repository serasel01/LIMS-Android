package com.example.serasel.lims;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class LimsTab extends AppCompatActivity {
    EditText a,b,c,d,e,f,g,h,i,j;
    SharedPreferences prefs;
    private HashMap<String, Book> booklist;
    Activity activity;
    TableLayout tb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_lims_tab);

        booklist = (HashMap<String, Book>) getIntent().getSerializableExtra("booklist");
        initV();
        prefs = this.getPreferences(MODE_PRIVATE);

    }

    private void initV() {
        tb = (TableLayout) findViewById(R.id.tb);
        displayBooks();
//        readPreferences();

    }
    private void displayBooks () {
        if (booklist.isEmpty() || booklist == null) {
            Toast.makeText(getApplicationContext(), "Inventory Complete. No missing books", Toast.LENGTH_LONG).show();
        }

        else {

            for (Map.Entry<String, Book> entry: booklist.entrySet()){
                Book book = entry.getValue();
                if (!book.isScanned()){
                    TableRow tableRow = new TableRow(getApplicationContext());
                    for (int i=0; i<2; i++){
                        TextView textView = new TextView(getApplicationContext());
                        textView.setTextColor(Color.BLACK);

                        if (i==0) {
                            textView.setText(book.getTitle());
                        }
                        else if (i==1){
                            textView.setText(book.getBarcode());
                        }

                        tableRow.addView(textView);
                    }
                    tb.addView(tableRow);
                }
            }

        }


    }



//    public void sve (View view) {
//        String n = a.getText().toString();
//        String m = b.getText().toString();
//        String o = c.getText().toString();
//        String p = d.getText().toString();
//        String q = e.getText().toString();
//        String r = f.getText().toString();
//        String s = g.getText().toString();
//        String t = h.getText().toString();
//        String u = i.getText().toString();
//        String v = j.getText().toString();
//
//
//
//        SharedPreferences.Editor editor = prefs.edit();
//        editor.putString("keyname", n);
//        editor.putString("keyname1", m);
//        editor.putString("keyname2", o);
//        editor.putString("keyname3", p);
//        editor.putString("keyname4", q);
//        editor.putString("keyname5", r);
//        editor.putString("keyname6", s);
//        editor.putString("keyname7", t);
//        editor.putString("keyname8", u);
//        editor.putString("keyname9", v);
//        editor.apply();
//
//
//    }


//    public void readPreferences() {
//        String ip1 = prefs.getString("keyname", "");
//        a.setText(ip1);
//        String ip2 = prefs.getString("keyname1", "");
//        b.setText(ip2);
//        String ip3 = prefs.getString("keyname2", "");
//        c.setText(ip3);
//        String ip4 = prefs.getString("keyname3", "");
//        d.setText(ip4);
//        String ip5 = prefs.getString("keyname4", "");
//        e.setText(ip5);
//        String ip6 = prefs.getString("keyname5", "");
//        f.setText(ip6);
//        String ip7 = prefs.getString("keyname6", "");
//        g.setText(ip7);
//        String ip8 = prefs.getString("keyname7", "");
//        h.setText(ip8);
//        String ip9 = prefs.getString("keyname8", "");
//        i.setText(ip9);
//        String ipT = prefs.getString("keyname9", "");
//        j.setText(ipT);
//    }

}
