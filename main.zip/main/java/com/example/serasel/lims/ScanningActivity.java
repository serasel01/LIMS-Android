package com.example.serasel.lims;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Parcelable;
import android.renderscript.ScriptGroup;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


public class ScanningActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private ImageView iv_book;
    private ImageButton btn_scan;
    private Button btn_ip, btn_tab, btn_add,btn_input;
    private TableLayout tbl_logs;
    private Activity activity;
    private TextView textView2;
    private Spinner dropB;
    private String section;
    private HashSet<String> logs;
    private BottomNavigationView BottomNav;

    private static final int ADD_BOOK_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanning);
        activity = this;
        initViews();
        displayLogs();
    }

    public void displayLogs() {
        tbl_logs.removeAllViews();
        if (SharedPrefs.getInstance(getApplicationContext()).getLogs() == null){
            logs = new HashSet<>();
            SharedPrefs.getInstance(getApplicationContext()).startLog();
        } else {
            logs = SharedPrefs.getInstance(getApplicationContext()).getLogs();

            for (String log : logs){
                TableRow tableRow = new TableRow(getApplicationContext());
                TextView textView = new TextView(getApplicationContext());
                textView.setTextColor(Color.WHITE);
                textView.setText(log.replaceAll("\\\\", "\n"));
                tableRow.addView(textView);
                tbl_logs.addView(tableRow);
            }
        }
    }

    public interface GetListCallBack {
        void onListCallBack(HashMap<String, Book> bookList);
    }

    private void initViews() {
        btn_scan = findViewById(R.id.btn_scan);
//        btn_tab = findViewById(R.id.btn_tab);
//        btn_add = findViewById(R.id.btn_add);
//        btn_input = findViewById(R.id.btn_in);
        textView2 = findViewById(R.id.textView2);
        BottomNav = (BottomNavigationView) findViewById(R.id.navigation);
        activity = this;
//        btn_ip = findViewById(R.id.btn_ip);
        dropB = findViewById(R.id.dropB);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Sections, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropB.setAdapter(adapter);
        dropB.setOnItemSelectedListener(this);

//        btn_input.setOnClickListener(new InputBarcode ());
        btn_scan.setOnClickListener(new BookScanner());
//        btn_tab.setOnClickListener(new ShowList());
//        btn_add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                addBook();
//            }
//        });

        BottomNav.setOnNavigationItemSelectedListener(new BottomNavi());

        tbl_logs = findViewById(R.id.tbl_logs);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        section = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {}

    private class BookScanner implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            IntentIntegrator integrator = new IntentIntegrator(activity);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.CODE_39);
            integrator.setPrompt("Scan a barcode\n *If scanner is not able to scan, use 'Enter BC' from the menu*\n You are on section: " + section);
            integrator.setCameraId(0);  // Use a specific camera of the device
            integrator.setBeepEnabled(false);
            integrator.setBarcodeImageEnabled(true);
            integrator.setOrientationLocked(false);
            integrator.initiateScan();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        final IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        displayLogs();

        if(result != null) {
            if(result.getContents() == null) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();

            } else {
                textView2.setText("Recently scanned: " + result.getContents());

                DBCaller caller = new DBCaller(getApplicationContext());
                caller.getListOfBooks(dropB.getSelectedItem().toString(), new GetListCallBack() {
                    @Override
                    public void onListCallBack(HashMap<String, Book> bookList) {
                        Book book = bookList.get(result.getContents());

                        if (bookList.containsKey(result.getContents())){
                            if(book.isScanned()){
                                Toast.makeText(getApplicationContext(),
                                            "This book was already scanned",
                                            Toast.LENGTH_LONG).show();
                                SharedPrefs.getInstance(getApplicationContext())
                                        .updateLog(bookList.get(result.getContents()).getTitle()
                                                + " (" + bookList.get(result.getContents())
                                                .getBarcode() + ") was already scanned.");

                                MediaPlayer beep = MediaPlayer.create(getApplicationContext(), R.raw.bip);
                                beep.start();
                                displayLogs();

                            } else {
                                new DBCaller(activity).updateToDatabase(result.getContents(), bookList);
                                Toast.makeText(getApplicationContext(), "Scanned: " + result.getContents(),
                                            Toast.LENGTH_LONG).show();
                                    SharedPrefs.getInstance(getApplicationContext())
                                            .updateLog(book.getTitle() + " (" + book.getBarcode() + ") successfully scanned.");
                                    MediaPlayer beep = MediaPlayer.create(getApplicationContext(), R.raw.bip2);
                                    beep.start();
                                    displayLogs();
                            }

                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "This book does not belong to this section",
                                    Toast.LENGTH_LONG).show();
                            MediaPlayer beep = MediaPlayer.create(getApplicationContext(), R.raw.bip);
                            beep.start();
                        }

                    }
                });

            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void addBook () {
        Intent add = new Intent(this, AddBook.class);
        startActivityForResult(add, ADD_BOOK_REQUEST);
    }

    public void LimsTab(HashMap<String, Book> bookList) {
        Intent it = new Intent(this, LimsTab.class);
        it.putExtra("booklist", bookList);
        startActivity(it);
    }

    private class BottomNavi implements BottomNavigationView.OnNavigationItemSelectedListener {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.bc:
                        InputBtn InB = new InputBtn(activity, section, textView2);
                        InB.show();
                        return true;

                    case R.id.btn_tab:
                        new DBCaller(getApplicationContext()).getListOfBooks(section, new GetListCallBack(){
                            @Override
                            public void onListCallBack(HashMap<String, Book> bookList) {
                                LimsTab(bookList);
                            }
                        });
                        return true;
                    case R.id.ad:
                        addBook();
                        return true;

                    case R.id.logout:
                        new LogoutDialog(ScanningActivity.this).show();
                        return true;
                }
                return false;
            }
        }

}
