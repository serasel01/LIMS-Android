package com.example.serasel.lims;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Book implements Parcelable {
    private String title,barcode;
    private int id, total_no, no_scanned;
    private boolean isScanned;

    protected Book(Parcel in) {
        title = in.readString();
        barcode = in.readString();
        id = in.readInt();
        total_no = in.readInt();
        no_scanned = in.readInt();
        isScanned = in.readByte() != 0;
    }

    public static final Creator<Book> CREATOR = new Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTotal_no() {
        return total_no;
    }

    public void setTotal_no(int total_no) {
        this.total_no = total_no;
    }

    public boolean isScanned() {
        return isScanned;
    }

    public void setScanned(boolean scanned) {
        isScanned = scanned;
    }

    public int getNo_scanned() {
        return no_scanned;
    }

    public void setNo_scanned(int no_scanned) {
        this.no_scanned = no_scanned;
    }

    public Book(String title, String barcode, int id, int total_no) {
        this.title = title;
        this.barcode = barcode;
        this.id = id;
        this.total_no = total_no;
    }

    public Book() {

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(barcode);
        dest.writeInt(id);
        dest.writeInt(total_no);
        dest.writeInt(no_scanned);
        dest.writeByte((byte) (isScanned ? 1 : 0));
    }
}
