package com.example.serasel.lims;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends Dialog{

    private static final String SHARED_PREF_NAME = "my_shared_pref";
    private Button sve, cnl;
    private TextView tv;
    private Activity activity;
    private EditText et;
    private SharedPrefs prefs;
    private final String sample = "sample";

    public Main2Activity(Activity activity) { //constructor
        super(activity);
        this.activity = activity;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main2);

        initViews();
    }
    private void initViews() {
        sve = findViewById(R.id.sve);
        cnl = findViewById(R.id.cnl);
        tv = findViewById(R.id.tv);
        et = findViewById(R.id.et);

        sve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sav();
            }
        });

        cnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                can();
            }
        });
        readPreferences();
    }

    public void sav() {
        String ip = et.getText().toString();
        SharedPrefs.getInstance(getContext()).updateMeow(ip);
    }

    public void can() {
        this.dismiss();
    }
    public void readPreferences() {
        String ip1 = SharedPrefs.getInstance(getContext()).getIpaddress();
        et.setText(ip1);
    }


}
