package com.example.serasel.lims;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class IPAddressActivity extends Dialog {
    private Activity activity;
    private Button sve, cnl;
    private TextView tv, textView;
    private EditText et;
    private ImageView ip_check;

    public IPAddressActivity(Activity activity) {
        super(activity);
        this.activity = activity;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_ipaddress);

        initViews();
    }
    private void initViews() {
       sve = findViewById(R.id.sve);
       cnl = findViewById(R.id.cnl);
       tv = findViewById(R.id.tv);
       et = findViewById(R.id.et);
       textView = findViewById(R.id.textView2);
       ip_check = activity.findViewById(R.id.ip_check);

        sve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sav();
            }
        });

        cnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                can();
            }
        });
        readPreferences();
    }

    public void sav() {
        String ip = et.getText().toString();
        SharedPrefs.getInstance(getContext()).updateMeow(ip);
        this.dismiss();

        DBCaller caller = new DBCaller(getContext());

    }

    public void can() {
        this.dismiss();
    }
    public void readPreferences() {
        String ip1 = SharedPrefs.getInstance(getContext()).getIpaddress();
        et.setText(ip1);
    }


}
