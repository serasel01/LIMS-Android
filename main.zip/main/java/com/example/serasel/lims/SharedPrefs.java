package com.example.serasel.lims;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SharedPrefs {
    private static SharedPrefs mInstance;
    private static Context mCtx;
    private static final String SHARED_PREF_NAME = "my_shared_pref";
    private static final String IPADDRESS = "address";
    private static final String BOOKLIST = "booklist";
    private static final String LOGS = "logs";
    private static final String ID = "id";

    private SharedPrefs(Context context){
        mCtx = context;
    }

    public static synchronized SharedPrefs getInstance(Context context){
        if(mInstance == null){
            mInstance = new SharedPrefs(context);
        }
        return mInstance;
    }
    public void updateMeow(String meow){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(IPADDRESS, meow);
        editor.apply();
    }

    public void updateList(ArrayList<Book> booklist){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Gson gson = new Gson();
        String jsonList = gson.toJson(booklist);
        editor.putString(BOOKLIST, jsonList);
        editor.apply();
    }

    public void logout(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.clear();
        editor.apply();
    }

    public String getIpaddress(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(IPADDRESS, null);
    }

    public HashSet<String> getLogs(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return (HashSet<String>) sharedPreferences.getStringSet(LOGS, null);
    }

    public void startLog(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        HashSet<String> logs = new HashSet<>();
        editor.putStringSet(LOGS, logs);
        editor.apply();
    }

    public void updateLog(String log){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        HashSet<String> logs = getLogs();
        logs.add(log);

        editor.putStringSet(LOGS, logs);
        editor.apply();
    }

    public ArrayList<Book> getBookList() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String jsonList = sharedPreferences.getString(BOOKLIST, null);

        Type type = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> booklist = gson.fromJson(jsonList, type);
        return booklist;
    }

    public void updateId(String id) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(ID, id);
        editor.apply();
    }

    public String getId() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(ID, null);
    }
}
