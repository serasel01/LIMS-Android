package com.example.serasel.lims;

import android.app.Dialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class InputBtn extends Dialog implements AdapterView.OnItemSelectedListener {
    private Activity act;
    private Button btn_enter, cancel;
    private TextView txt, txtView,textView2;
    private EditText edit;
    private Spinner dropB;
    private String section;

    public InputBtn(Activity act, String section, TextView textView2) {
        super(act);
        this.act = act;
        this.section = section;
        this.textView2 = textView2;
    }

    public interface GetListCallBack {
        void onListCallBack(HashMap<String, Book> bookList);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_input_btn);

        initViews();
    }

    private void initViews() {
        btn_enter = findViewById(R.id.save);
        cancel = findViewById(R.id.cancel);
        txt = findViewById(R.id.tx);
        edit = findViewById(R.id.ed);
        txtView = findViewById(R.id.textView2);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cn();
            }
        });

        btn_enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sav();
                dismiss();
            }
        });
    }

    private void sav() {
        DBCaller caller = new DBCaller(act.getApplicationContext());
        caller.getListOfBooks(section, new InputBtn.GetListCallBack() {
            @Override
            public void onListCallBack(HashMap<String, Book> bookList) {
                Book book = bookList.get(edit.getText().toString().trim());

                if (bookList.containsKey(edit.getText().toString().trim())){
                    if(book.isScanned()){
                        Toast.makeText(act.getApplicationContext(),
                                "This book was already scanned",
                                Toast.LENGTH_LONG).show();
                        SharedPrefs.getInstance(act.getApplicationContext())
                                .updateLog(bookList.get(edit.getText().toString().trim()).getTitle()
                                        + " (" + bookList.get(edit.getText().toString().trim())
                                        .getBarcode() + ") was already scanned.");

                        MediaPlayer beep = MediaPlayer.create(act.getApplicationContext(), R.raw.bip);
                        beep.start();

                    } else {
                        new DBCaller(act.getApplicationContext()).updateToDatabase(edit.getText().toString().trim(), bookList);
                        Toast.makeText(act.getApplicationContext(), "Scanned: " + edit.getText().toString().trim(),
                                Toast.LENGTH_LONG).show();
                        SharedPrefs.getInstance(act.getApplicationContext())
                                .updateLog(book.getTitle() + " (" + book.getBarcode() + ") successfully scanned.");
                        MediaPlayer beep = MediaPlayer.create(act.getApplicationContext(), R.raw.bip2);
                        beep.start();
                    }

                } else {
                    Toast.makeText(act.getApplicationContext(),
                            "This book does not belong to this section",
                            Toast.LENGTH_LONG).show();
                    MediaPlayer beep = MediaPlayer.create(act.getApplicationContext(), R.raw.bip);
                    beep.start();
                }

            }
        });
    }

    private void cn() {
        this.dismiss();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        section= parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
